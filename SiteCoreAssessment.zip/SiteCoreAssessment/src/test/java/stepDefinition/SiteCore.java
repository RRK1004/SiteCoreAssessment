package stepDefinition;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.HttpsURLConnection;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import Utility.*;




public class SiteCore extends  MyUtils{
	

	@Given("Go to Carlist Malaysia Website")
	public void go_to_carlist_malaysia_website() throws Exception {
		LaunchBrowser("http://carlist.my");
		System.out.println("Carlist malaysia website opened successfully");
	}

	@When("Select Used Radio Button")
	public void select_used_radio_button() throws Exception {
	    clickonButton(By.xpath("(//input[@placeholder=\"All Condition\"])[1]"));
	    WaitAndClickElementDirectly(gettingWebElement(By.xpath("(//div[@data-value=\"used\"])[1]")));
	    System.out.println("Used Option is selected");
	    
	}

	@When("Click on “Search” button")
	public void click_on_search_button() throws Exception {
	  WaitAndClickElementDirectly(gettingWebElement(By.xpath("(//button[@type=\"submit\"])[1]")));
	  System.out.println("Clicked Search Button");
	}

	@When("Click on the first result")
	public void click_on_the_first_result() throws Exception {
		waitForVisibilityOfElementLocated(By.xpath("(//a[text()='All'])[2]"));
		System.out.println("Moved to Used Car page");
	   gettingWebElement(By.xpath("(//div[@class=\"grid\"]//article//a)[1]")).click();
	   
	   System.out.println("Clicked First Car in the search result");
	}

	
	@Then("Validate the car price is more than RM {double}")
	public void validate_the_car_price_is_more_than_rm(Double double1) throws Exception {

		String CarValue = gettingWebElement(By.xpath("//div[@class=\"listing__item-price\"]/span")).getText();
		
		System.out.println("Car price per month : " + CarValue);
		
		String[] CarValueSplit = CarValue.split(" ");
		Double CarPrice = Double.valueOf(CarValueSplit[1]);
		if(CarPrice > double1) {
		System.out.println("Car price is more than RM 1000");	
		
		}
		else {
			System.out.println("Car price is less than RM 1000");	
			
			
		}

	}
	
}
